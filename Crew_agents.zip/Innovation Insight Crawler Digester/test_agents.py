#!/usr/bin/env python3
"""
Test script for individual agents
"""

import sys
from agents import (
    ArxivAgentHandler,
    ViXraAgentHandler,
    SSRNAgentHandler,
    SummarizerAgentHandler
)
from config import settings

def test_arxiv():
    """Test ArXiv agent."""
    print("\n" + "=" * 70)
    print("Testing ArXiv Agent")
    print("=" * 70)
    
    handler = ArxivAgentHandler()
    papers = handler.fetch_papers()
    
    print(f"\nFound {len(papers)} papers:")
    for i, paper in enumerate(papers, 1):
        print(f"\n{i}. {paper.title}")
        print(f"   Authors: {', '.join(paper.authors)}")
        print(f"   Date: {paper.published_date}")
        print(f"   Category: {paper.category}")
        print(f"   URL: {paper.pdf_url}")
    
    return papers

def test_vixra():
    """Test ViXra agent."""
    print("\n" + "=" * 70)
    print("Testing ViXra Agent")
    print("=" * 70)
    
    handler = ViXraAgentHandler()
    papers = handler.fetch_papers()
    
    print(f"\nFound {len(papers)} papers:")
    for i, paper in enumerate(papers, 1):
        print(f"\n{i}. {paper.title}")
        print(f"   Authors: {', '.join(paper.authors)}")
        print(f"   Date: {paper.published_date}")
        print(f"   Category: {paper.category}")
        print(f"   URL: {paper.pdf_url}")
    
    return papers

def test_ssrn():
    """Test SSRN agent."""
    print("\n" + "=" * 70)
    print("Testing SSRN Agent")
    print("=" * 70)
    
    handler = SSRNAgentHandler()
    papers = handler.fetch_papers()
    
    print(f"\nFound {len(papers)} papers:")
    for i, paper in enumerate(papers, 1):
        print(f"\n{i}. {paper.title}")
        print(f"   Authors: {', '.join(paper.authors)}")
        print(f"   Date: {paper.published_date}")
        print(f"   Category: {paper.category}")
        print(f"   URL: {paper.pdf_url}")
    
    return papers

def test_summarizer(papers):
    """Test Summarizer agent."""
    print("\n" + "=" * 70)
    print("Testing Summarizer Agent")
    print("=" * 70)
    
    if not papers:
        print("No papers to summarize")
        return
    
    handler = SummarizerAgentHandler()
    
    # Test with first paper only
    test_paper = papers[0]
    print(f"\nSummarizing: {test_paper.title}")
    
    summarized = handler.summarize_papers([test_paper])
    
    print(f"\nSummary:\n{summarized[0].summary}")
    
    return summarized

def main():
    """Run tests based on command line arguments."""
    if len(sys.argv) < 2:
        print("Usage: python test_agents.py [arxiv|vixra|ssrn|summarizer|all]")
        sys.exit(1)
    
    test_type = sys.argv[1].lower()
    
    if test_type == "arxiv":
        test_arxiv()
    elif test_type == "vixra":
        test_vixra()
    elif test_type == "ssrn":
        test_ssrn()
    elif test_type == "summarizer":
        # Test with ArXiv papers
        papers = test_arxiv()
        if papers:
            test_summarizer(papers)
    elif test_type == "all":
        arxiv_papers = test_arxiv()
        vixra_papers = test_vixra()
        ssrn_papers = test_ssrn()
        
        all_papers = arxiv_papers + vixra_papers + ssrn_papers
        if all_papers:
            test_summarizer(all_papers[:1])  # Test with one paper
    else:
        print(f"Unknown test type: {test_type}")
        print("Valid options: arxiv, vixra, ssrn, summarizer, all")
        sys.exit(1)

if __name__ == "__main__":
    main()