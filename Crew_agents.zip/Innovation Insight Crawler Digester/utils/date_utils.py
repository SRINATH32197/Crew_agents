from datetime import datetime, timedelta, timezone

def get_date_range(days_back=5):
    """Get the date range for searching papers."""
    end_date = datetime.now()
    start_date = end_date - timedelta(days=days_back)
    return start_date, end_date

def is_paper_recent(published_date, days_back: int) -> bool:
    cutoff_date = datetime.now(timezone.utc) - timedelta(days=days_back)
    return published_date >= cutoff_date

def format_date(date):
    """Format a date for display."""
    if isinstance(date, str):
        date = datetime.fromisoformat(date.replace('Z', '+00:00'))
    return date.strftime('%B %d, %Y')