import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from config import settings
from utils.date_utils import format_date

class EmailBuilder:
    @staticmethod
    def build_html_email(arxiv_papers, vixra_papers, ssrn_papers):
        """Build HTML email with all papers grouped by source."""
        
        html_content = """
        <!DOCTYPE html>
        <html>
        <head>
            <style>
                body {
                    font-family: Arial, sans-serif;
                    line-height: 1.6;
                    color: #333;
                    max-width: 900px;
                    margin: 0 auto;
                    padding: 20px;
                }
                .header {
                    background-color: #2c3e50;
                    color: white;
                    padding: 20px;
                    text-align: center;
                    border-radius: 5px;
                    margin-bottom: 30px;
                }
                .section {
                    margin-bottom: 40px;
                    border-radius: 5px;
                    padding: 20px;
                    box-shadow: 0 2px 5px rgba(0,0,0,0.1);
                }
                .arxiv-section {
                    background-color: #e8f5e9;
                    border-left: 5px solid #4caf50;
                }
                .vixra-section {
                    background-color: #e3f2fd;
                    border-left: 5px solid #2196f3;
                }
                .ssrn-section {
                    background-color: #fff3e0;
                    border-left: 5px solid #ff9800;
                }
                .section-title {
                    font-size: 24px;
                    font-weight: bold;
                    margin-bottom: 20px;
                    padding-bottom: 10px;
                    border-bottom: 2px solid;
                }
                .arxiv-section .section-title {
                    color: #4caf50;
                    border-bottom-color: #4caf50;
                }
                .vixra-section .section-title {
                    color: #2196f3;
                    border-bottom-color: #2196f3;
                }
                .ssrn-section .section-title {
                    color: #ff9800;
                    border-bottom-color: #ff9800;
                }
                .paper {
                    background-color: white;
                    padding: 15px;
                    margin-bottom: 20px;
                    border-radius: 5px;
                    border: 1px solid #ddd;
                }
                .paper-title {
                    font-size: 18px;
                    font-weight: bold;
                    color: #2c3e50;
                    margin-bottom: 10px;
                }
                .paper-meta {
                    color: #666;
                    font-size: 14px;
                    margin-bottom: 10px;
                }
                .paper-summary {
                    margin: 15px 0;
                    padding: 10px;
                    background-color: #f9f9f9;
                    border-left: 3px solid #3498db;
                    font-style: italic;
                }
                .paper-link {
                    display: inline-block;
                    background-color: #3498db;
                    color: white;
                    padding: 8px 15px;
                    text-decoration: none;
                    border-radius: 3px;
                    margin-top: 10px;
                }
                .paper-link:hover {
                    background-color: #2980b9;
                }
                .category-badge {
                    display: inline-block;
                    padding: 3px 8px;
                    border-radius: 3px;
                    font-size: 12px;
                    font-weight: bold;
                    margin-left: 10px;
                }
                .jailbreak-badge {
                    background-color: #e74c3c;
                    color: white;
                }
                .redteam-badge {
                    background-color: #9b59b6;
                    color: white;
                }
                .footer {
                    text-align: center;
                    margin-top: 40px;
                    padding-top: 20px;
                    border-top: 2px solid #ddd;
                    color: #666;
                }
            </style>
        </head>
        <body>
            <div class="header">
                <h1>🔬Innovation Insight Crawler Digest</h1>
                <p>Recent papers on LLM , Jailbreaks and Red Teaming</p>
            </div>
        """
        
        # ArXiv Section
        if arxiv_papers:
            html_content += """
            <div class="section arxiv-section">
                <div class="section-title">📚 ArXiv Papers</div>
            """
            for paper in arxiv_papers:
                html_content += EmailBuilder._format_paper(paper)
            html_content += "</div>"
        
        # ViXra Section
        if vixra_papers:
            html_content += """
            <div class="section vixra-section">
                <div class="section-title">📘 ViXra Papers</div>
            """
            for paper in vixra_papers:
                html_content += EmailBuilder._format_paper(paper)
            html_content += "</div>"
        
        # SSRN Section
        if ssrn_papers:
            html_content += """
            <div class="section ssrn-section">
                <div class="section-title">📙 SSRN Papers</div>
            """
            for paper in ssrn_papers:
                html_content += EmailBuilder._format_paper(paper)
            html_content += "</div>"
        
        html_content += """
            <div class="footer">
                <p>This digest was automatically generated by the Innovation Insight Crawler Digester</p>
                <p>Stay informed about the latest developments in LLM security!</p>
            </div>
        </body>
        </html>
        """
        
        return html_content
    
    @staticmethod
    def _format_paper(paper):
        """Format a single paper as HTML."""
        authors = ", ".join(paper.authors)
        date_str = format_date(paper.published_date)
        
        category_badge = ""
        if paper.category:
            badge_class = "jailbreak-badge" if paper.category == "jailbreak" else "redteam-badge"
            category_badge = f'<span class="category-badge {badge_class}">{paper.category.upper()}</span>'
        
        return f"""
        <div class="paper">
            <div class="paper-title">
                {paper.title}
                {category_badge}
            </div>
            <div class="paper-meta">
                <strong>Authors:</strong> {authors}<br>
                <strong>Published:</strong> {date_str}
            </div>
            <div class="paper-summary">
                {paper.summary if paper.summary else paper.abstract[:300] + "..."}
            </div>
            <a href="{paper.pdf_url}" class="paper-link" target="_blank">📥 Download PDF</a>
        </div>
        """
    
    @staticmethod
    def send_email(arxiv_papers, vixra_papers, ssrn_papers):
        """Send the email with all papers."""
        try:
            html_content = EmailBuilder.build_html_email(arxiv_papers, vixra_papers, ssrn_papers)
            
            msg = MIMEMultipart('alternative')
            msg['Subject'] = f"🔬 Innovation Insight Crawler Digester - {format_date(datetime.now())}"
            msg['From'] = settings.SENDER_EMAIL
            msg['To'] = ", ".join(settings.RECIPIENT_EMAILS)
            
            html_part = MIMEText(html_content, 'html')
            msg.attach(html_part)
            
            with smtplib.SMTP(settings.SMTP_SERVER, settings.SMTP_PORT) as server:
                server.starttls()
                server.login(settings.SENDER_EMAIL, settings.SENDER_PASSWORD)
                server.send_message(msg)
            
            print(f"✅ Email sent successfully to {', '.join(settings.RECIPIENT_EMAILS)}")
            return True
            
        except Exception as e:
            print(f"❌ Error sending email: {e}")
            return False

from datetime import datetime



















































# import smtplib
# from email.mime.text import MIMEText
# from email.mime.multipart import MIMEMultipart
# from config import settings
# from utils.date_utils import format_date
# from datetime import datetime

# class EmailBuilder:
#     @staticmethod
#     def build_html_email(arxiv_papers, vixra_papers, ssrn_papers):
#         """Build HTML email with all papers grouped by source."""
        
#         html_content = """
#         <!DOCTYPE html>
#         <html>
#         <head>
#             <style>
#                 body {
#                     font-family: Arial, sans-serif;
#                     line-height: 1.6;
#                     color: #333;
#                     max-width: 900px;
#                     margin: 0 auto;
#                     padding: 20px;
#                 }
#                 .header {
#                     background-color: #2c3e50;
#                     color: white;
#                     padding: 20px;
#                     text-align: center;
#                     border-radius: 5px;
#                     margin-bottom: 30px;
#                 }
#                 .section {
#                     margin-bottom: 40px;
#                     border-radius: 5px;
#                     padding: 20px;
#                     box-shadow: 0 2px 5px rgba(0,0,0,0.1);
#                 }
#                 .arxiv-section {
#                     background-color: #e8f5e9;
#                     border-left: 5px solid #4caf50;
#                 }
#                 .vixra-section {
#                     background-color: #e3f2fd;
#                     border-left: 5px solid #2196f3;
#                 }
#                 .ssrn-section {
#                     background-color: #fff3e0;
#                     border-left: 5px solid #ff9800;
#                 }
#                 .section-title {
#                     font-size: 24px;
#                     font-weight: bold;
#                     margin-bottom: 20px;
#                     padding-bottom: 10px;
#                     border-bottom: 2px solid;
#                 }
#                 .arxiv-section .section-title {
#                     color: #4caf50;
#                     border-bottom-color: #4caf50;
#                 }
#                 .vixra-section .section-title {
#                     color: #2196f3;
#                     border-bottom-color: #2196f3;
#                 }
#                 .ssrn-section .section-title {
#                     color: #ff9800;
#                     border-bottom-color: #ff9800;
#                 }
#                 .paper {
#                     background-color: white;
#                     padding: 15px;
#                     margin-bottom: 20px;
#                     border-radius: 5px;
#                     border: 1px solid #ddd;
#                 }
#                 .paper-title {
#                     font-size: 18px;
#                     font-weight: bold;
#                     color: #2c3e50;
#                     margin-bottom: 10px;
#                 }
#                 .paper-meta {
#                     color: #666;
#                     font-size: 14px;
#                     margin-bottom: 10px;
#                 }
#                 .paper-summary {
#                     margin: 15px 0;
#                     padding: 10px;
#                     background-color: #f9f9f9;
#                     border-left: 3px solid #3498db;
#                     font-style: italic;
#                 }
#                 .paper-link {
#                     display: inline-block;
#                     background-color: #3498db;
#                     color: white;
#                     padding: 8px 15px;
#                     text-decoration: none;
#                     border-radius: 3px;
#                     margin-top: 10px;
#                 }
#                 .paper-link:hover {
#                     background-color: #2980b9;
#                 }
#                 .category-badge {
#                     display: inline-block;
#                     padding: 3px 8px;
#                     border-radius: 3px;
#                     font-size: 12px;
#                     font-weight: bold;
#                     margin-left: 10px;
#                 }
#                 .jailbreak-badge {
#                     background-color: #e74c3c;
#                     color: white;
#                 }
#                 .redteam-badge {
#                     background-color: #9b59b6;
#                     color: white;
#                 }
#                 .footer {
#                     text-align: center;
#                     margin-top: 40px;
#                     padding-top: 20px;
#                     border-top: 2px solid #ddd;
#                     color: #666;
#                 }
#             </style>
#         </head>
#         <body>
#             <div class="header">
#                 <h1>LLM Security Research Papers Digest</h1>
#                 <p>Recent papers on LLM Jailbreaks and Red Teaming</p>
#             </div>
#         """
        
#         # ArXiv Section
#         if arxiv_papers:
#             html_content += """
#             <div class="section arxiv-section">
#                 <div class="section-title">ArXiv Papers</div>
#             """
#             for paper in arxiv_papers:
#                 html_content += EmailBuilder._format_paper(paper)
#             html_content += "</div>"
        
#         # ViXra Section
#         if vixra_papers:
#             html_content += """
#             <div class="section vixra-section">
#                 <div class="section-title">ViXra Papers</div>
#             """
#             for paper in vixra_papers:
#                 html_content += EmailBuilder._format_paper(paper)
#             html_content += "</div>"
        
#         # SSRN Section
#         if ssrn_papers:
#             html_content += """
#             <div class="section ssrn-section">
#                 <div class="section-title">SSRN Papers</div>
#             """
#             for paper in ssrn_papers:
#                 html_content += EmailBuilder._format_paper(paper)
#             html_content += "</div>"
        
#         html_content += """
#             <div class="footer">
#                 <p>This digest was automatically generated by the LLM Research Paper Monitor</p>
#                 <p>Stay informed about the latest developments in LLM security!</p>
#             </div>
#         </body>
#         </html>
#         """
        
#         return html_content
    
#     @staticmethod
#     def _format_paper(paper):
#         """Format a single paper as HTML."""
#         authors = ", ".join(paper.authors)
#         date_str = format_date(paper.published_date)
        
#         category_badge = ""
#         if paper.category:
#             badge_class = "jailbreak-badge" if paper.category == "jailbreak" else "redteam-badge"
#             category_badge = f'<span class="category-badge {badge_class}">{paper.category.upper()}</span>'
        
#         return f"""
#         <div class="paper">
#             <div class="paper-title">
#                 {paper.title}
#                 {category_badge}
#             </div>
#             <div class="paper-meta">
#                 <strong>Authors:</strong> {authors}<br>
#                 <strong>Published:</strong> {date_str}
#             </div>
#             <div class="paper-summary">
#                 {paper.summary if paper.summary else paper.abstract[:300] + "..."}
#             </div>
#             <a href="{paper.pdf_url}" class="paper-link" target="_blank">Download PDF</a>
#         </div>
#         """
    
#     @staticmethod
#     def send_email(arxiv_papers, vixra_papers, ssrn_papers):
#         """Send the email with all papers."""
#         try:
#             html_content = EmailBuilder.build_html_email(arxiv_papers, vixra_papers, ssrn_papers)
            
#             msg = MIMEMultipart('alternative')
#             msg['Subject'] = f"LLM Security Papers Digest - {format_date(datetime.now())}"
#             msg['From'] = settings.SENDER_EMAIL
#             msg['To'] = ", ".join(settings.RECIPIENT_EMAILS)
            
#             html_part = MIMEText(html_content, 'html')
#             msg.attach(html_part)
            
#             with smtplib.SMTP(settings.SMTP_SERVER, settings.SMTP_PORT) as server:
#                 server.starttls()
#                 server.login(settings.SENDER_EMAIL, settings.SENDER_PASSWORD)
#                 server.send_message(msg)
            
#             print(f">>> Email sent successfully to {', '.join(settings.RECIPIENT_EMAILS)}")
#             return True
            
#         except Exception as e:
#             print(f">>> Error sending email: {e}")
#             return False