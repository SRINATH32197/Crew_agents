# import google.generativeai as genai
# from config import settings

# class GeminiClient:
#     def __init__(self):
#         genai.configure(api_key=settings.GEMINI_API_KEY)
#         self.model = genai.GenerativeModel('gemini-pro')
    
#     def generate_summary(self, paper_title, paper_abstract):
#         """Generate a concise summary of a research paper."""
#         prompt = f"""
#         Please provide a concise summary (3-4 sentences) of the following research paper:
        
#         Title: {paper_title}
        
#         Abstract: {paper_abstract}
        
#         Focus on:
#         1. The main problem addressed
#         2. The key methodology or approach
#         3. The primary findings or contributions
        
#         Summary:
#         """
        
#         try:
#             response = self.model.generate_content(prompt)
#             return response.text.strip()
#         except Exception as e:
#             print(f"Error generating summary: {e}")
#             return "Summary generation failed."
    
#     def batch_summarize(self, papers):
#         """Generate summaries for multiple papers."""
#         summaries = []
#         for paper in papers:
#             summary = self.generate_summary(paper.title, paper.abstract)
#             paper.summary = summary
#             summaries.append(summary)
#         return summaries

# gemini_client = GeminiClient()







































import google.generativeai as genai
from config import settings
import time

class GeminiClient:
    def __init__(self):
        genai.configure(api_key=settings.GEMINI_API_KEY)
        # Updated model name - gemini-pro is deprecated
        self.model = genai.GenerativeModel('gemini-1.5-flash')
    
    def generate_summary(self, paper_title, paper_abstract):
        """Generate a concise summary of a research paper."""
        prompt = f"""
        Please provide a concise summary (3-4 sentences) of the following research paper:
        
        Title: {paper_title}
        
        Abstract: {paper_abstract}
        
        Focus on:
        1. The main problem addressed
        2. The key methodology or approach
        3. The primary findings or contributions
        
        Summary:
        """
        
        try:
            response = self.model.generate_content(prompt)
            time.sleep(1)  # Rate limiting
            return response.text.strip()
        except Exception as e:
            print(f"Error generating summary: {e}")
            # Return first 200 chars of abstract as fallback
            return paper_abstract[:200] + "..." if len(paper_abstract) > 200 else paper_abstract
    
    def batch_summarize(self, papers):
        """Generate summaries for multiple papers."""
        summaries = []
        for i, paper in enumerate(papers, 1):
            print(f"  Summarizing {i}/{len(papers)}: {paper.title[:50]}...")
            summary = self.generate_summary(paper.title, paper.abstract)
            paper.summary = summary
            summaries.append(summary)
        return summaries

gemini_client = GeminiClient()