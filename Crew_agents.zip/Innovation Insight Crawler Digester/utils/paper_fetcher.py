# import arxiv
# import requests
# import feedparser
# from bs4 import BeautifulSoup
# from datetime import datetime, timedelta
# from models import Paper
# from utils.date_utils import is_paper_recent

# class ArxivFetcher:
#     @staticmethod
#     def fetch_papers(query, max_results=10, days_back=5, category_filter=None):
#         """Fetch papers from arXiv with optional category filtering."""
#         papers = []
#         client = arxiv.Client()
        
#         search = arxiv.Search(
#             query=query,
#             max_results=max_results * 3,  # Fetch more to account for filtering
#             sort_by=arxiv.SortCriterion.SubmittedDate,
#             sort_order=arxiv.SortOrder.Descending
#         )
        
#         for result in client.results(search):
#             # Check if paper is recent
#             if is_paper_recent(result.published, days_back):
#                 paper = Paper(
#                     title=result.title,
#                     authors=[author.name for author in result.authors],
#                     abstract=result.summary,
#                     published_date=result.published,
#                     pdf_url=result.pdf_url,
#                     source='arxiv',
#                     category=''
#                 )
#                 papers.append(paper)
                
#                 if len(papers) >= max_results:
#                     break
        
#         return papers

# class ViXraFetcher:
#     @staticmethod
#     def fetch_papers(query_terms, max_results=10, days_back=5):
#         """Fetch papers from viXra (uses RSS feed)."""
#         papers = []
        
#         # viXra RSS feed for recent submissions
#         rss_url = "https://vixra.org/recent.rss"
        
#         try:
#             print(f"   Fetching from: {rss_url}")
#             feed = feedparser.parse(rss_url)
            
#             if not feed.entries:
#                 print("   ⚠️  No entries found in ViXra RSS feed")
#                 return papers
            
#             print(f"   Found {len(feed.entries)} total entries in feed")
            
#             for entry in feed.entries:
#                 try:
#                     # Check if any query term is in title or summary
#                     title_lower = entry.title.lower() if hasattr(entry, 'title') else ""
#                     summary_lower = entry.get('summary', '').lower()
                    
#                     # More lenient matching - just look for AI/ML/LLM related content
#                     matches = any(term.lower() in title_lower or term.lower() in summary_lower 
#                                  for term in query_terms)
                    
#                     if matches:
#                         # Parse publication date
#                         if hasattr(entry, 'published_parsed') and entry.published_parsed:
#                             published_date = datetime(*entry.published_parsed[:6])
#                         elif hasattr(entry, 'updated_parsed') and entry.updated_parsed:
#                             published_date = datetime(*entry.updated_parsed[:6])
#                         else:
#                             published_date = datetime.now()
                        
#                         if is_paper_recent(published_date, days_back):
#                             # Extract PDF link
#                             pdf_link = entry.link if hasattr(entry, 'link') else ""
                            
#                             paper = Paper(
#                                 title=entry.title,
#                                 authors=[entry.get('author', 'Unknown')],
#                                 abstract=entry.get('summary', 'No abstract available')[:500],
#                                 published_date=published_date,
#                                 pdf_url=pdf_link,
#                                 source='vixra',
#                                 category=''
#                             )
#                             papers.append(paper)
#                             print(f"   ✓ Matched: {entry.title[:60]}...")
                            
#                             if len(papers) >= max_results:
#                                 break
#                 except Exception as e:
#                     print(f"   ⚠️  Error parsing entry: {e}")
#                     continue
                    
#         except Exception as e:
#             print(f"   ❌ Error fetching from viXra: {e}")
        
#         return papers

# class SSRNFetcher:
#     @staticmethod
#     def fetch_papers(query, max_results=10, days_back=5):
#         """Fetch papers from SSRN."""
#         papers = []
        
#         # SSRN search URL
#         search_url = f"https://papers.ssrn.com/sol3/results.cfm"
#         params = {
#             'npage': 1,
#             'form_name': 'journalBrowse',
#             'SortOrder': 'ab_approval_date',
#             'query': query
#         }
        
#         try:
#             response = requests.get(search_url, params=params, timeout=10)
#             soup = BeautifulSoup(response.content, 'html.parser')
            
#             # Parse SSRN results (structure may vary)
#             results = soup.find_all('div', class_='paper-row')
            
#             for result in results[:max_results * 2]:
#                 try:
#                     title_elem = result.find('h3')
#                     title = title_elem.text.strip() if title_elem else "Unknown Title"
                    
#                     author_elem = result.find('div', class_='authors')
#                     authors = [author_elem.text.strip()] if author_elem else ["Unknown"]
                    
#                     abstract_elem = result.find('div', class_='abstract')
#                     abstract = abstract_elem.text.strip() if abstract_elem else "No abstract"
                    
#                     link_elem = result.find('a', href=True)
#                     pdf_url = f"https://papers.ssrn.com{link_elem['href']}" if link_elem else ""
                    
#                     # SSRN date parsing might need adjustment
#                     date_elem = result.find('span', class_='date')
#                     if date_elem:
#                         date_str = date_elem.text.strip()
#                         try:
#                             published_date = datetime.strptime(date_str, '%B %d, %Y')
#                         except:
#                             published_date = datetime.now()
#                     else:
#                         published_date = datetime.now()
                    
#                     if is_paper_recent(published_date, days_back):
#                         paper = Paper(
#                             title=title,
#                             authors=authors,
#                             abstract=abstract,
#                             published_date=published_date,
#                             pdf_url=pdf_url,
#                             source='ssrn',
#                             category=''
#                         )
#                         papers.append(paper)
                        
#                         if len(papers) >= max_results:
#                             break
                            
#                 except Exception as e:
#                     print(f"Error parsing SSRN result: {e}")
#                     continue
                    
#         except Exception as e:
#             print(f"Error fetching from SSRN: {e}")
        
#         return papers












































import arxiv
import requests
import feedparser
from bs4 import BeautifulSoup
from datetime import datetime, timedelta
from models import Paper
from utils.date_utils import is_paper_recent


class ArxivFetcher:
    @staticmethod
    def fetch_papers(query, max_results=10, days_back=5, category_filter=None):
        """Fetch papers from arXiv with optional category filtering."""
        papers = []
        client = arxiv.Client()
        
        search = arxiv.Search(
            query=query,
            max_results=max_results * 3,  # Fetch more to account for filtering
            sort_by=arxiv.SortCriterion.SubmittedDate,
            sort_order=arxiv.SortOrder.Descending
        )
        
        for result in client.results(search):
            if is_paper_recent(result.published, days_back):
                paper = Paper(
                    title=result.title,
                    authors=[author.name for author in result.authors],
                    abstract=result.summary,
                    published_date=result.published,
                    pdf_url=result.pdf_url,
                    source="arxiv",
                    category=", ".join(result.categories) if result.categories else ""
                )
                papers.append(paper)
                
                if len(papers) >= max_results:
                    break
        
        return papers






class ViXraFetcher:
    @staticmethod
    def fetch_papers(query_terms, max_results=15, days_back=5):
        """
        Fetch papers from viXra by scraping /all/ page.
        Filters papers containing query_terms in title or abstract.
        """
        papers = []
        url = "https://vixra.org/all/"
        headers = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                          "AppleWebKit/537.36 (KHTML, like Gecko) "
                          "Chrome/117.0 Safari/537.36",
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,/;q=0.8",
            "Accept-Language": "en-US,en;q=0.9",
        }

        try:
            response = requests.get(url, headers=headers, timeout=10)
            response.raise_for_status()  # raises HTTPError if blocked
            soup = BeautifulSoup(response.text, "html.parser")

            # viXra lists recent papers in <ul><li> tags
            entries = soup.select("ul li")

            if not entries:
                print("⚠ No entries found on the ViXra page")
                return papers

            for e in entries:
                # Title and link
                a_tag = e.find("a")
                if not a_tag:
                    continue
                title = a_tag.text.strip()
                link = "https://vixra.org" + a_tag["href"]

                # Authors (usually in <i>)
                author_tag = e.find("i")
                authors = [author_tag.text.strip()] if author_tag else ["Unknown"]

                # Abstract snippet (text after first <br>)
                summary = ""
                br_tags = e.find_all("br")
                if br_tags and br_tags[0].next_sibling:
                    summary = br_tags[0].next_sibling.strip()

                combined_text = (title + " " + summary).lower()
                if any(term.lower() in combined_text for term in query_terms):
                    published_date = datetime.now()  # viXra doesn’t always show dates
                    if is_paper_recent(published_date, days_back):
                        paper = Paper(
                            title=title,
                            authors=authors,
                            abstract=summary[:500],
                            published_date=published_date,
                            pdf_url=link,
                            source="vixra",
                            category=""
                        )
                        papers.append(paper)
                        print(f"   ✓ Matched: {title[:60]}...")

                        if len(papers) >= max_results:
                            break

        except Exception as e:
            print(f"❌ Error scraping ViXra: {e}")

        return papers
    


    
class SSRNFetcher:
    @staticmethod
    def fetch_papers(query, max_results=10, days_back=5):
        """Fetch papers from SSRN."""
        papers = []
        search_url = "https://papers.ssrn.com/"  # SSRN search page
        params = {
            "npage": 1,
            "form_name": "journalBrowse",
            "SortOrder": "ab_approval_date",
            "query": query
        }

        headers = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                          "AppleWebKit/537.36 (KHTML, like Gecko) "
                          "Chrome/117.0 Safari/537.36",
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,/;q=0.8",
            "Accept-Language": "en-US,en;q=0.9",
        }

        try:
            response = requests.get(search_url, params=params, headers=headers, timeout=10)
            response.raise_for_status()  # raises HTTPError if blocked
            soup = BeautifulSoup(response.content, "html.parser")

            results = soup.find_all("div", class_="paper-row")
            for result in results[:max_results * 2]:
                try:
                    title_elem = result.find("h3")
                    title = title_elem.text.strip() if title_elem else "Unknown Title"

                    author_elem = result.find("div", class_="authors")
                    authors = [author_elem.text.strip()] if author_elem else ["Unknown"]

                    abstract_elem = result.find("div", class_="abstract")
                    abstract = abstract_elem.text.strip() if abstract_elem else "No abstract"

                    link_elem = result.find("a", href=True)
                    pdf_url = f"https://papers.ssrn.com{link_elem['href']}" if link_elem else ""

                    date_elem = result.find("span", class_="date")
                    if date_elem:
                        date_str = date_elem.text.strip()
                        try:
                            published_date = datetime.strptime(date_str, "%B %d, %Y")
                        except Exception:
                            published_date = datetime.now()
                    else:
                        published_date = datetime.now()

                    if is_paper_recent(published_date, days_back):
                        paper = Paper(
                            title=title,
                            authors=authors,
                            abstract=abstract,
                            published_date=published_date,
                            pdf_url=pdf_url,
                            source="ssrn",
                            category=""
                        )
                        papers.append(paper)
                        if len(papers) >= max_results:
                            break
                except Exception as e:
                    print(f"⚠ Error parsing SSRN result: {e}")
                    continue

        except Exception as e:
            print(f"❌ Error fetching from SSRN: {e}")

        return papers