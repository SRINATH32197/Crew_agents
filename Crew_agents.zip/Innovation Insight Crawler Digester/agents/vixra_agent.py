# from crewai import Agent
# from langchain_google_genai import ChatGoogleGenerativeAI
# from config import settings
# from utils import ViXraFetcher

# class ViXraAgentHandler:
#     def __init__(self):
#         self.llm = ChatGoogleGenerativeAI(
#             model="gemini-pro",
#             google_api_key=settings.GEMINI_API_KEY
#         )
#         self.fetcher = ViXraFetcher()
    
#     def create_agent(self):
#         """Create the ViXra agent."""
#         return Agent(
#             role="ViXra Research Paper Collector",
#             goal="Fetch 3 LLM jailbreak papers and 2 LLM red teaming papers from ViXra published in the last 5 days",
#             backstory="""You are a specialized research assistant focused on alternative academic repositories like ViXra.
#             You understand the importance of diverse sources in research and excel at finding cutting-edge
#             papers on LLM security, jailbreaking, and red teaming from non-traditional venues.""",
#             llm=self.llm,
#             verbose=True,
#             allow_delegation=False
#         )
    
#     def fetch_papers(self):
#         """Fetch papers from ViXra."""
#         print("🔍 Fetching papers from ViXra...")
        
#         # Fetch jailbreak papers
#         jailbreak_papers = self.fetcher.fetch_papers(
#             query_terms=["LLM", "jailbreak", "language model", "prompt injection"],
#             max_results=3,
#             days_back=settings.DAYS_BACK
#         )
        
#         for paper in jailbreak_papers:
#             paper.category = "jailbreak"
        
#         # Fetch red team papers
#         redteam_papers = self.fetcher.fetch_papers(
#             query_terms=["LLM", "red team", "adversarial", "testing"],
#             max_results=2,
#             days_back=settings.DAYS_BACK
#         )
        
#         for paper in redteam_papers:
#             paper.category = "redteam"
        
#         all_papers = jailbreak_papers + redteam_papers
        
#         print(f"✅ Found {len(all_papers)} papers from ViXra ({len(jailbreak_papers)} jailbreak, {len(redteam_papers)} red team)")
        
#         return all_papers














from crewai import Agent
from langchain_google_genai import ChatGoogleGenerativeAI
from config import settings
from utils import ViXraFetcher

class ViXraAgentHandler:
    def __init__(self):
        self.llm = ChatGoogleGenerativeAI(
            model="gemini-1.5-flash",
            google_api_key=settings.GEMINI_API_KEY
        )
        self.fetcher = ViXraFetcher()
    
    def create_agent(self):
        """Create the ViXra agent."""
        return Agent(
            role="ViXra Research Paper Collector",
            goal="Fetch 3 LLM jailbreak papers and 2 LLM red teaming papers from ViXra published in the last 30 days",
            backstory="""You are a specialized research assistant focused on alternative academic repositories like ViXra.
            You understand the importance of diverse sources in research and excel at finding cutting-edge
            papers on LLM security, jailbreaking, and red teaming from non-traditional venues.""",
            llm=self.llm,
            verbose=True,
            allow_delegation=False
        )
    
    def fetch_papers(self):
        """Fetch papers from ViXra."""
        print("Fetching papers from ViXra...")
        
        # Try multiple searches with broader terms
        all_papers = []
        
        # Search 1: AI and ML papers
        ai_papers = self.fetcher.fetch_papers(
            query_terms=["artificial intelligence", "machine learning", "neural network"],
            max_results=5,
            days_back=settings.DAYS_BACK
        )
        all_papers.extend(ai_papers)
        
        # Search 2: LLM and language models
        llm_papers = self.fetcher.fetch_papers(
            query_terms=["language model", "LLM", "GPT", "transformer"],
            max_results=5,
            days_back=settings.DAYS_BACK
        )
        all_papers.extend(llm_papers)
        
        # Remove duplicates based on title
        seen_titles = set()
        unique_papers = []
        for paper in all_papers:
            if paper.title not in seen_titles:
                seen_titles.add(paper.title)
                # Classify papers
                if any(term in paper.title.lower() or term in paper.abstract.lower() 
                       for term in ['jailbreak', 'attack', 'adversarial', 'injection']):
                    paper.category = "jailbreak"
                else:
                    paper.category = "redteam"
                unique_papers.append(paper)
        
        # Limit to requested amounts
        jailbreak_papers = [p for p in unique_papers if p.category == "jailbreak"][:3]
        redteam_papers = [p for p in unique_papers if p.category == "redteam"][:2]
        
        all_papers = jailbreak_papers + redteam_papers
        
        print(f">>> Found {len(all_papers)} papers from ViXra ({len(jailbreak_papers)} jailbreak, {len(redteam_papers)} red team)")
        
        return all_papers