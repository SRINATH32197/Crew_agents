# from crewai import Agent
# from langchain_google_genai import ChatGoogleGenerativeAI
# from config import settings
# from utils import gemini_client

# class SummarizerAgentHandler:
#     def __init__(self):
#         self.llm = ChatGoogleGenerativeAI(
#             model="gemini-pro",
#             google_api_key=settings.GEMINI_API_KEY
#         )
#         self.gemini = gemini_client
    
#     def create_agent(self):
#         """Create the Summarizer agent."""
#         return Agent(
#             role="Research Paper Summarizer",
#             goal="Create concise, informative summaries of all collected research papers using Gemini AI",
#             backstory="""You are an expert technical writer and research analyst with deep expertise in machine learning
#             and cybersecurity. You excel at distilling complex research papers into clear, accessible summaries
#             that highlight key findings, methodologies, and implications. You use advanced AI to ensure
#             accuracy and comprehensiveness in your summaries.""",
#             llm=self.llm,
#             verbose=True,
#             allow_delegation=False
#         )
    
#     def summarize_papers(self, all_papers):
#         """Summarize all collected papers."""
#         print(f"📝 Summarizing {len(all_papers)} papers using Gemini AI...")
        
#         for i, paper in enumerate(all_papers, 1):
#             print(f"  Summarizing paper {i}/{len(all_papers)}: {paper.title[:50]}...")
#             summary = self.gemini.generate_summary(paper.title, paper.abstract)
#             paper.summary = summary
        
#         print("✅ All papers summarized successfully")
        
#         return all_papers
















from crewai import Agent
from langchain_google_genai import ChatGoogleGenerativeAI
from config import settings
from utils import gemini_client

class SummarizerAgentHandler:
    def __init__(self):
        self.llm = ChatGoogleGenerativeAI(
            model="gemini-1.5-flash",
            google_api_key=settings.GEMINI_API_KEY
        )
        self.gemini = gemini_client
    
    def create_agent(self):
        """Create the Summarizer agent."""
        return Agent(
            role="Research Paper Summarizer",
            goal="Create concise, informative summaries of all collected research papers using Gemini AI",
            backstory="""You are an expert technical writer and research analyst with deep expertise in machine learning
            and cybersecurity. You excel at distilling complex research papers into clear, accessible summaries
            that highlight key findings, methodologies, and implications. You use advanced AI to ensure
            accuracy and comprehensiveness in your summaries.""",
            llm=self.llm,
            verbose=True,
            allow_delegation=False
        )
    
    def summarize_papers(self, all_papers):
        """Summarize all collected papers."""
        print(f"Summarizing {len(all_papers)} papers using Gemini AI...")
        
        for i, paper in enumerate(all_papers, 1):
            print(f"  Summarizing paper {i}/{len(all_papers)}: {paper.title[:50]}...")
            try:
                summary = self.gemini.generate_summary(paper.title, paper.abstract)
                paper.summary = summary
                print(f"  >>> Summary generated successfully")
            except Exception as e:
                print(f"  >>> Error: {e}")
                paper.summary = paper.abstract[:200] + "..."
        
        print(">>> All papers summarized successfully")
        
        return all_papers