# from crewai import Agent
# from langchain_google_genai import ChatGoogleGenerativeAI
# from config import settings
# from utils import SSRNFetcher

# class SSRNAgentHandler:
#     def __init__(self):
#         self.llm = ChatGoogleGenerativeAI(
#             model="gemini-pro",
#             google_api_key=settings.GEMINI_API_KEY
#         )
#         self.fetcher = SSRNFetcher()
    
#     def create_agent(self):
#         """Create the SSRN agent."""
#         return Agent(
#             role="SSRN Research Paper Collector",
#             goal="Fetch 3 LLM jailbreak papers and 2 LLM red teaming papers from SSRN published in the last 5 days",
#             backstory="""You are a research specialist focusing on social science research networks and interdisciplinary papers.
#             You excel at finding papers that bridge computer science with other fields, particularly
#             those discussing the societal and security implications of LLM vulnerabilities.""",
#             llm=self.llm,
#             verbose=True,
#             allow_delegation=False
#         )
    
#     def fetch_papers(self):
#         """Fetch papers from SSRN."""
#         print("🔍 Fetching papers from SSRN...")
        
#         # Fetch jailbreak papers
#         jailbreak_papers = self.fetcher.fetch_papers(
#             query="LLM jailbreak language model",
#             max_results=3,
#             days_back=settings.DAYS_BACK
#         )
        
#         for paper in jailbreak_papers:
#             paper.category = "jailbreak"
        
#         # Fetch red team papers
#         redteam_papers = self.fetcher.fetch_papers(
#             query="LLM red team adversarial",
#             max_results=2,
#             days_back=settings.DAYS_BACK
#         )
        
#         for paper in redteam_papers:
#             paper.category = "redteam"
        
#         all_papers = jailbreak_papers + redteam_papers
        
#         print(f"✅ Found {len(all_papers)} papers from SSRN ({len(jailbreak_papers)} jailbreak, {len(redteam_papers)} red team)")
        
#         return all_papers













from crewai import Agent
from langchain_google_genai import ChatGoogleGenerativeAI
from config import settings
from utils import SSRNFetcher

class SSRNAgentHandler:
    def __init__(self):
        self.llm = ChatGoogleGenerativeAI(
            model="gemini-1.5-flash",
            google_api_key=settings.GEMINI_API_KEY
        )
        self.fetcher = SSRNFetcher()
    
    def create_agent(self):
        """Create the SSRN agent."""
        return Agent(
            role="SSRN Research Paper Collector",
            goal="Fetch 3 LLM jailbreak papers and 2 LLM red teaming papers from SSRN published in the last 30 days",
            backstory="""You are a research specialist focusing on social science research networks and interdisciplinary papers.
            You excel at finding papers that bridge computer science with other fields, particularly
            those discussing the societal and security implications of LLM vulnerabilities.""",
            llm=self.llm,
            verbose=True,
            allow_delegation=False
        )
    
    def fetch_papers(self):
        """Fetch papers from SSRN."""
        print("Fetching papers from SSRN...")
        
        all_papers = []
        
        # Try multiple search queries
        search_queries = [
            "artificial intelligence security",
            "machine learning safety",
            "AI risk",
            "language model",
            "chatbot security"
        ]
        
        for query in search_queries:
            papers = self.fetcher.fetch_papers(
                query=query,
                max_results=2,
                days_back=settings.DAYS_BACK
            )
            all_papers.extend(papers)
            
            if len(all_papers) >= 5:
                break
        
        # Remove duplicates
        seen_titles = set()
        unique_papers = []
        for paper in all_papers:
            if paper.title not in seen_titles:
                seen_titles.add(paper.title)
                # Classify papers
                if any(term in paper.title.lower() or term in paper.abstract.lower() 
                       for term in ['jailbreak', 'attack', 'adversarial', 'vulnerability']):
                    paper.category = "jailbreak"
                else:
                    paper.category = "redteam"
                unique_papers.append(paper)
        
        # Limit to requested amounts
        jailbreak_papers = [p for p in unique_papers if p.category == "jailbreak"][:3]
        redteam_papers = [p for p in unique_papers if p.category == "redteam"][:2]
        
        all_papers = jailbreak_papers + redteam_papers
        
        print(f">>> Found {len(all_papers)} papers from SSRN ({len(jailbreak_papers)} jailbreak, {len(redteam_papers)} red team)")
        
        return all_papers