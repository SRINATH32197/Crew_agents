from crewai import Agent
from langchain_google_genai import ChatGoogleGenerativeAI
from config import settings
from utils import EmailBuilder

class EmailAgentHandler:
    def __init__(self):
        self.llm = ChatGoogleGenerativeAI(
            model="gemini-pro",
            google_api_key=settings.GEMINI_API_KEY
        )
        self.email_builder = EmailBuilder()
    
    def create_agent(self):
        """Create the Email agent."""
        return Agent(
            role="Research Digest Email Coordinator",
            goal="Compile all research papers and summaries into a well-formatted email and send it to recipients",
            backstory="""You are a professional communications specialist who excels at creating informative,
            visually appealing email digests. You organize information logically, use color coding
            for clarity, and ensure all recipients receive comprehensive, actionable research updates.
            You maintain strict attention to detail in formatting and presentation.""",
            llm=self.llm,
            verbose=True,
            allow_delegation=False
        )
    
    def send_email(self, arxiv_papers, vixra_papers, ssrn_papers):
        """Send email with all papers."""
        print(f"📧 Sending email digest to {', '.join(settings.RECIPIENT_EMAILS)}...")
        
        success = self.email_builder.send_email(arxiv_papers, vixra_papers, ssrn_papers)
        
        if success:
            print("✅ Email sent successfully!")
        else:
            print("❌ Failed to send email")
        
        return success