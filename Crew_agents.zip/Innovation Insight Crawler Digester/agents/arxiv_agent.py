# from crewai import Agent
# from langchain_google_genai import ChatGoogleGenerativeAI
# from config import settings
# from utils import ArxivFetcher

# class ArxivAgentHandler:
#     def __init__(self):
#         self.llm = ChatGoogleGenerativeAI(
#             model="gemini-pro",
#             google_api_key=settings.GEMINI_API_KEY
#         )
#         self.fetcher = ArxivFetcher()
    
#     def create_agent(self):
#         """Create the ArXiv agent."""
#         return Agent(
#             role="ArXiv Research Paper Collector",
#             goal="Fetch 3 LLM jailbreak papers and 2 LLM red teaming papers from ArXiv published in the last 5 days",
#             backstory="""You are an expert research assistant specializing in collecting academic papers from ArXiv.
#             You have deep knowledge of LLM security topics including jailbreaking techniques and red teaming methodologies.
#             Your mission is to identify and retrieve the most relevant and recent papers on these topics.""",
#             llm=self.llm,
#             verbose=True,
#             allow_delegation=False
#         )
    
#     def fetch_papers(self):
#         """Fetch papers from ArXiv."""
#         print("🔍 Fetching papers from ArXiv...")
        
#         # Fetch jailbreak papers
#         jailbreak_papers = self.fetcher.fetch_papers(
#             query="LLM jailbreak OR language model jailbreak",
#             max_results=3,
#             days_back=settings.DAYS_BACK
#         )
        
#         for paper in jailbreak_papers:
#             paper.category = "jailbreak"
        
#         # Fetch red team papers
#         redteam_papers = self.fetcher.fetch_papers(
#             query="LLM red team OR language model adversarial testing",
#             max_results=2,
#             days_back=settings.DAYS_BACK
#         )
        
#         for paper in redteam_papers:
#             paper.category = "redteam"
        
#         all_papers = jailbreak_papers + redteam_papers
        
#         print(f"✅ Found {len(all_papers)} papers from ArXiv ({len(jailbreak_papers)} jailbreak, {len(redteam_papers)} red team)")
        
#         return all_papers



























# from crewai import Agent
# from langchain_google_genai import ChatGoogleGenerativeAI
# from config import settings
# from utils import ArxivFetcher

# class ArxivAgentHandler:
#     def __init__(self):
#         self.llm = ChatGoogleGenerativeAI(
#             model="gemini-pro",
#             google_api_key=settings.GEMINI_API_KEY
#         )
#         self.fetcher = ArxivFetcher()
    
#     def create_agent(self):
#         """Create the ArXiv agent."""
#         return Agent(
#             role="ArXiv Research Paper Collector",
#             goal="Fetch 3 LLM jailbreak papers and 2 LLM red teaming papers from ArXiv published in the last 5 days",
#             backstory="""You are an expert research assistant specializing in collecting academic papers from ArXiv.
#             You have deep knowledge of LLM security topics including jailbreaking techniques and red teaming methodologies.
#             Your mission is to identify and retrieve the most relevant and recent papers on these topics.""",
#             llm=self.llm,
#             verbose=True,
#             allow_delegation=False
#         )
    
#     def fetch_papers(self):
#         """Fetch papers from ArXiv."""
#         print("🔍 Fetching papers from ArXiv...")
        
#         # Fetch jailbreak papers with more specific query
#         jailbreak_papers = self.fetcher.fetch_papers(
#             query='cat:cs.CR AND (abs:"jailbreak" OR abs:"prompt injection" OR abs:"adversarial prompt")',
#             max_results=3,
#             days_back=settings.DAYS_BACK
#         )
        
#         for paper in jailbreak_papers:
#             paper.category = "jailbreak"
        
#         # Fetch red team papers with more specific query
#         redteam_papers = self.fetcher.fetch_papers(
#             query='cat:cs.CR AND (abs:"red team" OR abs:"adversarial testing" OR abs:"safety evaluation")',
#             max_results=2,
#             days_back=settings.DAYS_BACK
#         )
        
#         for paper in redteam_papers:
#             paper.category = "redteam"
        
#         all_papers = jailbreak_papers + redteam_papers
        
#         print(f"✅ Found {len(all_papers)} papers from ArXiv ({len(jailbreak_papers)} jailbreak, {len(redteam_papers)} red team)")
        
#         return all_papers















































from crewai import Agent
from langchain_google_genai import ChatGoogleGenerativeAI
from config import settings
from utils import ArxivFetcher

class ArxivAgentHandler:
    def __init__(self):
        self.llm = ChatGoogleGenerativeAI(
            model="gemini-1.5-flash",
            google_api_key=settings.GEMINI_API_KEY
        )
        self.fetcher = ArxivFetcher()
    
    def create_agent(self):
        """Create the ArXiv agent."""
        return Agent(
            role="ArXiv Research Paper Collector",
            goal="Fetch 3 LLM jailbreak papers and 2 LLM red teaming papers from ArXiv published in the last 30 days",
            backstory="""You are an expert research assistant specializing in collecting academic papers from ArXiv.
            You have deep knowledge of LLM security topics including jailbreaking techniques and red teaming methodologies.
            Your mission is to identify and retrieve the most relevant and recent papers on these topics.""",
            llm=self.llm,
            verbose=True,
            allow_delegation=False
        )
    
    def fetch_papers(self):
        """Fetch papers from ArXiv."""
        print("Fetching papers from ArXiv...")
        
        # Fetch jailbreak papers with more specific query
        jailbreak_papers = self.fetcher.fetch_papers(
            query='cat:cs.CR AND (abs:"jailbreak" OR abs:"prompt injection" OR abs:"adversarial prompt")',
            max_results=8,
            days_back=settings.DAYS_BACK
        )
        
        for paper in jailbreak_papers:
            paper.category = "jailbreak"
        
        # Fetch red team papers with more specific query
        redteam_papers = self.fetcher.fetch_papers(
            query='cat:cs.CR AND (abs:"red team" OR abs:"adversarial testing" OR abs:"safety evaluation")',
            max_results=7,
            days_back=settings.DAYS_BACK
        )
        
        for paper in redteam_papers:
            paper.category = "redteam"
        
        all_papers = jailbreak_papers + redteam_papers
        
        print(f">>> Found {len(all_papers)} papers from ArXiv ({len(jailbreak_papers)} jailbreak, {len(redteam_papers)} red team)")
        
        return all_papers