# #!/usr/bin/env python3
# """
# LLM Security Research Paper Monitor
# Main entry point for the crew-based paper fetching and emailing system
# """

# import sys
# import logging
# from datetime import datetime
# from agents import (
#     ArxivAgentHandler,
#     ViXraAgentHandler,
#     SSRNAgentHandler,
#     SummarizerAgentHandler,
#     EmailAgentHandler
# )
# from config import settings

# # Configure logging
# logging.basicConfig(
#     level=logging.INFO,
#     format='%(asctime)s - %(levelname)s - %(message)s',
#     handlers=[
#         logging.FileHandler(f'logs/run_{datetime.now().strftime("%Y%m%d_%H%M%S")}.log'),
#         logging.StreamHandler(sys.stdout)
#     ]
# )

# logger = logging.getLogger(__name__)

# def main():
#     """Main execution function."""
#     try:
#         logger.info("=" * 70)
#         logger.info("🚀 Starting LLM Security Research Paper Monitor")
#         logger.info("=" * 70)
        
#         # Validate configuration
#         if not settings.GEMINI_API_KEY:
#             logger.error("❌ GEMINI_API_KEY not found in environment variables")
#             sys.exit(1)
        
#         if not settings.SENDER_EMAIL or not settings.SENDER_PASSWORD:
#             logger.error("❌ Email credentials not found in environment variables")
#             sys.exit(1)
        
#         # Initialize agent handlers
#         logger.info("\n📦 Initializing agents...")
#         arxiv_handler = ArxivAgentHandler()
#         vixra_handler = ViXraAgentHandler()
#         ssrn_handler = SSRNAgentHandler()
#         summarizer_handler = SummarizerAgentHandler()
#         email_handler = EmailAgentHandler()
        
#         # Step 1: Fetch ArXiv papers
#         logger.info("\n" + "=" * 70)
#         logger.info("STEP 1: Fetching papers from ArXiv")
#         logger.info("=" * 70)
#         arxiv_papers = arxiv_handler.fetch_papers()
        
#         # Step 2: Fetch ViXra papers
#         logger.info("\n" + "=" * 70)
#         logger.info("STEP 2: Fetching papers from ViXra")
#         logger.info("=" * 70)
#         vixra_papers = vixra_handler.fetch_papers()
        
#         # Step 3: Fetch SSRN papers
#         logger.info("\n" + "=" * 70)
#         logger.info("STEP 3: Fetching papers from SSRN")
#         logger.info("=" * 70)
#         ssrn_papers = ssrn_handler.fetch_papers()
        
#         # Combine all papers
#         all_papers = arxiv_papers + vixra_papers + ssrn_papers
        
#         if not all_papers:
#             logger.warning("⚠️  No papers found from any source. Exiting.")
#             return
        
#         logger.info(f"\n📊 Total papers collected: {len(all_papers)}")
#         logger.info(f"   - ArXiv: {len(arxiv_papers)}")
#         logger.info(f"   - ViXra: {len(vixra_papers)}")
#         logger.info(f"   - SSRN: {len(ssrn_papers)}")
        
#         # Step 4: Summarize all papers
#         logger.info("\n" + "=" * 70)
#         logger.info("STEP 4: Generating summaries with Gemini AI")
#         logger.info("=" * 70)
#         all_papers = summarizer_handler.summarize_papers(all_papers)
        
#         # Update the original lists with summaries
#         arxiv_papers = [p for p in all_papers if p.source == 'arxiv']
#         vixra_papers = [p for p in all_papers if p.source == 'vixra']
#         ssrn_papers = [p for p in all_papers if p.source == 'ssrn']
        
#         # Step 5: Send email
#         logger.info("\n" + "=" * 70)
#         logger.info("STEP 5: Sending email digest")
#         logger.info("=" * 70)
#         success = email_handler.send_email(arxiv_papers, vixra_papers, ssrn_papers)
        
#         if success:
#             logger.info("\n" + "=" * 70)
#             logger.info("✅ PROCESS COMPLETED SUCCESSFULLY!")
#             logger.info("=" * 70)
#             logger.info(f"📧 Email sent to: {', '.join(settings.RECIPIENT_EMAILS)}")
#             logger.info(f"📚 Total papers: {len(all_papers)}")
#             logger.info("=" * 70)
#         else:
#             logger.error("\n❌ Email sending failed")
#             sys.exit(1)
            
#     except KeyboardInterrupt:
#         logger.info("\n⚠️  Process interrupted by user")
#         sys.exit(0)
#     except Exception as e:
#         logger.error(f"\n❌ An error occurred: {e}", exc_info=True)
#         sys.exit(1)

# if __name__ == "__main__":
#     main()

















































#!/usr/bin/env python3
"""
LLM Security Research Paper Monitor
Main entry point for the crew-based paper fetching and emailing system
"""

import sys
import logging
from datetime import datetime
from agents import (
    ArxivAgentHandler,
    ViXraAgentHandler,
    SSRNAgentHandler,
    SummarizerAgentHandler,
    EmailAgentHandler
)
from config import settings

# Configure logging with UTF-8 encoding
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler(f'logs/run_{datetime.now().strftime("%Y%m%d_%H%M%S")}.log', encoding='utf-8'),
        logging.StreamHandler(sys.stdout)
    ]
)

logger = logging.getLogger(__name__)

def main():
    """Main execution function."""
    try:
        logger.info("=" * 70)
        logger.info("Starting LLM Security Research Paper Monitor")
        logger.info("=" * 70)
        
        # Validate configuration
        if not settings.GEMINI_API_KEY:
            logger.error("X GEMINI_API_KEY not found in environment variables")
            sys.exit(1)
        
        if not settings.SENDER_EMAIL or not settings.SENDER_PASSWORD:
            logger.error("X Email credentials not found in environment variables")
            sys.exit(1)
        
        # Initialize agent handlers
        logger.info("\nInitializing agents...")
        arxiv_handler = ArxivAgentHandler()
        vixra_handler = ViXraAgentHandler()
        ssrn_handler = SSRNAgentHandler()
        summarizer_handler = SummarizerAgentHandler()
        email_handler = EmailAgentHandler()
        
        # Step 1: Fetch ArXiv papers
        logger.info("\n" + "=" * 70)
        logger.info("STEP 1: Fetching papers from ArXiv")
        logger.info("=" * 70)
        arxiv_papers = arxiv_handler.fetch_papers()
        
        # Step 2: Fetch ViXra papers
        logger.info("\n" + "=" * 70)
        logger.info("STEP 2: Fetching papers from ViXra")
        logger.info("=" * 70)
        vixra_papers = vixra_handler.fetch_papers()
        
        # Step 3: Fetch SSRN papers
        logger.info("\n" + "=" * 70)
        logger.info("STEP 3: Fetching papers from SSRN")
        logger.info("=" * 70)
        ssrn_papers = ssrn_handler.fetch_papers()
        
        # Combine all papers
        all_papers = arxiv_papers + vixra_papers + ssrn_papers
        
        if not all_papers:
            logger.warning("WARNING: No papers found from any source. Exiting.")
            return
        
        logger.info(f"\nTotal papers collected: {len(all_papers)}")
        logger.info(f"   - ArXiv: {len(arxiv_papers)}")
        logger.info(f"   - ViXra: {len(vixra_papers)}")
        logger.info(f"   - SSRN: {len(ssrn_papers)}")
        
        # Step 4: Summarize all papers
        logger.info("\n" + "=" * 70)
        logger.info("STEP 4: Generating summaries with Gemini AI")
        logger.info("=" * 70)
        all_papers = summarizer_handler.summarize_papers(all_papers)
        
        # Update the original lists with summaries
        arxiv_papers = [p for p in all_papers if p.source == 'arxiv']
        vixra_papers = [p for p in all_papers if p.source == 'vixra']
        ssrn_papers = [p for p in all_papers if p.source == 'ssrn']
        
        # Step 5: Send email
        logger.info("\n" + "=" * 70)
        logger.info("STEP 5: Sending email digest")
        logger.info("=" * 70)
        success = email_handler.send_email(arxiv_papers, vixra_papers, ssrn_papers)
        
        if success:
            logger.info("\n" + "=" * 70)
            logger.info("SUCCESS: PROCESS COMPLETED!")
            logger.info("=" * 70)
            logger.info(f"Email sent to: {', '.join(settings.RECIPIENT_EMAILS)}")
            logger.info(f"Total papers: {len(all_papers)}")
            logger.info("=" * 70)
        else:
            logger.error("\nX Email sending failed")
            sys.exit(1)
            
    except KeyboardInterrupt:
        logger.info("\nWARNING: Process interrupted by user")
        sys.exit(0)
    except Exception as e:
        logger.error(f"\nERROR: An error occurred: {e}", exc_info=True)
        sys.exit(1)

if __name__ == "__main__":
    main()