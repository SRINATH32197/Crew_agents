# import os
# from dotenv import load_dotenv

# load_dotenv()

# class Settings:
#     GEMINI_API_KEY = f"AIzaSyCag2J-mrhbGtl7uzMEO2nK4yrTejwRt9o"
#     SENDER_EMAIL = os.getenv("SENDER_EMAIL")
#     SENDER_PASSWORD = os.getenv("SENDER_PASSWORD")
#     RECIPIENT_EMAILS = os.getenv("RECIPIENT_EMAILS", "").split(",")
#     SMTP_SERVER = os.getenv("SMTP_SERVER", "smtp.gmail.com")
#     SMTP_PORT = int(os.getenv("SMTP_PORT", 587))
    
#     # Search parameters
#     DAYS_BACK = 10
#     ARXIV_JAILBREAK_PAPERS = 8
#     ARXIV_REDTEAM_PAPERS = 7
#     VIXRA_JAILBREAK_PAPERS = 3
#     VIXRA_REDTEAM_PAPERS = 2
#     SSRN_JAILBREAK_PAPERS = 3
#     SSRN_REDTEAM_PAPERS = 2
    
# settings = Settings()












import os
from dotenv import load_dotenv

# Load environment variables from .env file
load_dotenv()

class Settings:
    GEMINI_API_KEY = os.getenv("GEMINI_API_KEY")
    SENDER_EMAIL = os.getenv("SENDER_EMAIL")
    SENDER_PASSWORD = os.getenv("SENDER_PASSWORD")
    RECIPIENT_EMAILS = os.getenv("RECIPIENT_EMAILS", "").split(",")
    SMTP_SERVER = os.getenv("SMTP_SERVER", "smtp.gmail.com")
    SMTP_PORT = int(os.getenv("SMTP_PORT", 587))
    
    # Search parameters
    DAYS_BACK = 30  # Increased from 5 to 30 days
    ARXIV_JAILBREAK_PAPERS = 3
    ARXIV_REDTEAM_PAPERS = 2
    VIXRA_JAILBREAK_PAPERS = 3
    VIXRA_REDTEAM_PAPERS = 2
    SSRN_JAILBREAK_PAPERS = 3
    SSRN_REDTEAM_PAPERS = 2

# Create an instance for easy import
settings = Settings()