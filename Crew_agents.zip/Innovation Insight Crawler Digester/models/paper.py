from dataclasses import dataclass
from datetime import datetime
from typing import List

@dataclass
class Paper:
    title: str
    authors: List[str]
    abstract: str
    published_date: datetime
    pdf_url: str
    source: str  # 'arxiv', 'vixra', or 'ssrn'
    category: str  # 'jailbreak' or 'redteam'
    summary: str = ""
    
    def __str__(self):
        authors_str = ", ".join(self.authors)
        return f"{self.title} by {authors_str} ({self.published_date.strftime('%Y-%m-%d')})"
    
    def to_dict(self):
        return {
            'title': self.title,
            'authors': self.authors,
            'abstract': self.abstract,
            'published_date': self.published_date.isoformat(),
            'pdf_url': self.pdf_url,
            'source': self.source,
            'category': self.category,
            'summary': self.summary
        }