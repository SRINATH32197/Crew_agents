from .paper import Paper

__all__ = ['Paper']